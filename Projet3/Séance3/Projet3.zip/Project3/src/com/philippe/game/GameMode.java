package com.philippe.game;

public enum GameMode {

	// different playable modes  
	
	CHALLENGER(),
	DEFENSEUR(), 
	DUEL();	
	

}
