package com.philippe.game;

import com.philippe75.PlusMoins.ChallengerPlusMoins;
import com.philippe75.PlusMoins.DefenseurPlusMoins;
import com.philippe75.PlusMoins.PlusMoins;

public class Test {

	public static void main(String[] args) {
		
		
		
									// release the correct lines in order to see the differents elements working 
		
		Game plusMoins = new PlusMoins();  	
		plusMoins.startGame(GameMode.CHALLENGER);
//		System.out.println("************************************************");
//		
//		plusMoins.startGame(GameMode.DEFENSEUR);
//		System.out.println("************************************************");
//		
//		plusMoins.startGame(GameMode.DUEL);
//		System.out.println("************************************************\n");
//		
//		plusMoins.startMenu();
//		System.out.println("\n**********************************************");
		
		//-------------------------------------------------------------------------------
		
//		mastermind.startGame(GameMode.CHALLENGER);
//		System.out.println("************************************************");
//		
//		mastermind.startGame(GameMode.DEFENSEUR);
//		System.out.println("************************************************");
//		
//		mastermind.startGame(GameMode.DUEL);
//		System.out.println("************************************************\n");
//		
//		mastermind.startMenu();
//		System.out.println("\n**********************************************");
		
		//--------------------------------------------------------------------------------
		
//		Menu menu = new Menu(); 
//		menu.start();
		

	}

}
