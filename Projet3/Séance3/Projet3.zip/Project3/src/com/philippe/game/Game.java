package com.philippe.game;

public interface Game {
	
	public void startMenu();
	public void startGame(GameMode gameMode);
}
