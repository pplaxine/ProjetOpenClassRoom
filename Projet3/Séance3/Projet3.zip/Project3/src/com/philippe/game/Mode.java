package com.philippe.game;

public interface Mode {
	public void startChallengerMode();
	public void startDefenseurMode();
	public void startDuelMode();
}
