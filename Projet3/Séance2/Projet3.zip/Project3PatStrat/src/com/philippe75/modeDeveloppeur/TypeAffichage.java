package com.philippe75.modeDeveloppeur;

public interface TypeAffichage {
	public void selectAffichage();
}
