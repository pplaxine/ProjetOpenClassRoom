package com.philippe75.modeDeveloppeur;

public class ModeDeveloppeur implements TypeAffichage{
	@Override
	public void selectAffichage() {
		System.out.println("J'affiche en mode Developpeur donc je montre le chiffre secret.");
		
	}

}
