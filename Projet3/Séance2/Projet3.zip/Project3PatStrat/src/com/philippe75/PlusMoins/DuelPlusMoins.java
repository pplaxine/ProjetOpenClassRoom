package com.philippe75.PlusMoins;

public class DuelPlusMoins implements ModePlusMoins{
	@Override
	public void typeDeMode() {

		System.out.println("je lance le mode duel PlusMoins");
		
	}
}
