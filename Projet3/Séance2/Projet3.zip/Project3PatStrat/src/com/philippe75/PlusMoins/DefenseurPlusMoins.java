package com.philippe75.PlusMoins;

public class DefenseurPlusMoins implements ModePlusMoins{
	@Override
	public void typeDeMode() {

		System.out.println("je lance le mode Defenseur PlusMoins");
		
	}
}
