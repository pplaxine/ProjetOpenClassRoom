package com.philippe75.PlusMoins;

public interface ModePlusMoins {
	public void typeDeMode(); 
}
