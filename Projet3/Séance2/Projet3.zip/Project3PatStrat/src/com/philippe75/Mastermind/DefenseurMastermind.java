package com.philippe75.Mastermind;

public class DefenseurMastermind implements ModeMastermind{
	@Override
	public void typeDeMode() {

		System.out.println("je lance le mode Defenseur Mastermind");
		
	}
}
