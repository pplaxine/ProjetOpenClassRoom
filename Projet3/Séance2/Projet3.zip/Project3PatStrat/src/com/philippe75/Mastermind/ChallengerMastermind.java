package com.philippe75.Mastermind;

public class ChallengerMastermind implements ModeMastermind{
	@Override
	public void typeDeMode() {

		System.out.println("je lance le mode Challenger Mastermind");
		
	}

}
