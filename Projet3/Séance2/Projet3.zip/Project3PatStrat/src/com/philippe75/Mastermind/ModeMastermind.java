package com.philippe75.Mastermind;

public interface ModeMastermind {
	public void typeDeMode(); 
}
